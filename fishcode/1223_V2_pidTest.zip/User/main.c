#include "bsp.h"
#include "GetSensorData.h"/*��ȡMPU9250��Ԫ��*/


typedef struct{
	float limit;	//����޷�
	float target;	//Ŀ����
	float feedback;	//������
	float Kp;		
	float Ki;
	float Kd;
	float eSum;
	float e0;		//��ǰ���
	float e1;		//��һ�����
}PIDType;
 
//#define max(a, b)			( ( (a) > (b) )? (a):(b) )
//#define min(a, b)			( ( (a) < (b) )? (a):(b))
//#define range(x, a, b)		( min( max( (x), (a) ), (b) ) )
 
float pid_pos_update(PIDType *p)
{
	float pe, ie, de;
	float out=0;
 
	//���㵱ǰ���
	p->e0 = p->target - p->feedback;
 
	//������
	p->eSum += p->e0;
 
	//���΢��
	de = p->e0 - p->e1;
 
	pe = p->e0;
	ie = p->eSum;
 
	p->e1 = p->e0;
 
	out = pe*(p->Kp) + ie*(p->Ki) + de*(p->Kd);
	//����޷�
	out = range(out, -p->limit, p->limit);
	return out;
}

PIDType upsteer;

int main(void)
{
    BspInit();
    
    bsp_StartAutoTimer(0, 10); 
    
//800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 1900 2000 2100 2200 2300 2400 2500
//720 810 900  990  1080 1170 1260 1350 1440 1530 1620 1710 1800 1890 1980 2070 2160 2250
    
    
    while(1)
    {
        if(bsp_CheckTimer(0))
        { 
            
            GetSensorData();//��pitch�й�ϵ
            LED1_TOGGLE;
        }       
        
        
        
        
        
    }
}
