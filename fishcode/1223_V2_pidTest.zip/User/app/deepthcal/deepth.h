#ifndef DEEPTH_H
#define DEEPTH_H

#include "bsp.h"

void GetDeepthTemp(void);

extern float Deepth;
extern float Temperature;

#endif
